"""
This module contains exception implementations.
"""


class QecsimException(Exception):
    """Base qecsim exception"""
